var app = angular.module('login', []);
//app.controller('myCtrl', function ($scope) {
    //$scope.nombre = "John";
    //$scope.pass = "a@a.com";
//});