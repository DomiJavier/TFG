from django.contrib import admin
from .models import *
# REGISTRO DE MODELOS
admin.site.register(Evento)
